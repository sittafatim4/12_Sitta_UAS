public class Kendaraan12 {
    String noTNKB;
    String nama;
    String jenis;
    int cc;
    int tahun;
    int bulanHarusBayar;
    TransaksiPajak12 transaksiPajak;
    Kendaraan12 prev;
    Kendaraan12 next;
    
    Kendaraan12(String noTNKB, String nama, String jenis, int cc, int tahun, int bulanHarusBayar) {
        this.noTNKB = noTNKB;
        this.nama = nama;
        this.jenis = jenis;
        this.cc = cc;
        this.tahun = tahun;
        this.bulanHarusBayar = bulanHarusBayar;
    }   

    void setTransaksiPajak(TransaksiPajak12 transaksiPajak) {
        this.transaksiPajak = transaksiPajak;
    }

    void displayInfo() {
        System.out.println("No TNKB: " + noTNKB);
        System.out.println("Nama: " + nama);
        System.out.println("Jenis: " + jenis);
        System.out.println("CC: " + cc);
        System.out.println("Tahun: " + tahun);
        System.out.println("Bulan Harus Bayar: " + bulanHarusBayar);
        System.out.println("-----------------------------");
    }
}