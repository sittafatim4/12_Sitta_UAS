public class TransaksiPajak12 {
    static int counter = 1;
    int kode;
    long nominalBayar;
    long denda;
    int bulanBayar;
    TransaksiPajak12 prev;
    TransaksiPajak12 next;

    TransaksiPajak12(int kode, long nominalBayar, long denda, int bulanBayar) {
        this.kode = counter++;
        this.nominalBayar = nominalBayar;
        this.denda = denda;
        this.bulanBayar = bulanBayar;
    }

    void displayInfo() {
        System.out.println("Kode Transaksi: " + kode);
        System.out.println("Nominal Bayar: " + nominalBayar);
        System.out.println("Denda: " + denda);
        System.out.println("Bulan Bayar: " + bulanBayar);
        System.out.println("-----------------------------");
    }
}