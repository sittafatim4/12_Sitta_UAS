import java.util.Scanner;

public class Main12 {
    static Kendaraan12 headKendaraan;
    static TransaksiPajak12 headTransaksi;
    static int kendaraanCount = 0;
    static int transaksiCount = 0;

    public static void main(String[] args) {
        Scanner sc12 = new Scanner(System.in);
        int choice;

        Kendaraan12 kendaraan1 = new Kendaraan12("S 4567 YV", "Basko", "Mobil", 2000, 2012, 4);
        Kendaraan12 kendaraan2 = new Kendaraan12("N 4511 VS", "Arta", "Mobil", 2500, 2015, 3);
        Kendaraan12 kendaraan3 = new Kendaraan12("AB 4321 A", "Wisnu", "Motor", 125, 2010, 2);
        Kendaraan12 kendaraan4 = new Kendaraan12("B 1234 AG", "Sisa", "Motor", 150, 2020, 1);
        insertKendaraan(kendaraan1);
        insertKendaraan(kendaraan2);
        insertKendaraan(kendaraan3);
        insertKendaraan(kendaraan4);

        do {
            System.out.println("Menu");
            System.out.println("1. Daftar Kendaraan");
            System.out.println("2. Bayar Pajak");
            System.out.println("3. Tampilkan Seluruh Transaksi");
            System.out.println("4. Urutkan Transaksi Berdasarkan Nama Pemilik");
            System.out.println("5. Keluar");
            System.out.print("Pilih(1-5): ");
            choice = sc12.nextInt();

            switch (choice) {
                case 1:
                    tampilkanDaftarKendaraan();
                    break;
                case 2:
                    bayarPajak();
                    break;
                case 3:
                    tampilkanSeluruhTransaksi();
                    break;
                case 4:
                    System.out.println("Urutan transaksi berdasarkan nama pemilik belum didukung.");
                    break;
                case 5:
                    System.out.println("Keluar dari program.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid.");
                    break;
            }
        } while (choice != 5);
    }

    static void insertKendaraan(Kendaraan12 kendaraan) {
        if (headKendaraan == null) {
            headKendaraan = kendaraan;
        } else {
            Kendaraan12 current = headKendaraan;
            while (current.next != null) {
                current = current.next;
            }
            current.next = kendaraan;
            kendaraan.prev = current;
        }
        kendaraanCount++;
    }

    static void insertTransaksi(TransaksiPajak12 transaksi) {
        if (headTransaksi == null) {
            headTransaksi = transaksi;
        } else {
            TransaksiPajak12 current = headTransaksi;
            while (current.next != null) {
                current = current.next;
            }
            current.next = transaksi;
            transaksi.prev = current;
        }
        transaksiCount++;
    }

    static void tampilkanDaftarKendaraan() {
        System.out.println("++++++++++++++++++++++++++");
        System.out.println("Daftar Kendaraan:");
        System.out.println("++++++++++++++++++++++++++");
        Kendaraan12 current = headKendaraan;
        System.out.println("| No TNKB   | Nama      | Jenis  | CC   | Tahun | Bulan Harus Bayar |");
        while (current != null) {
            System.out.printf("| %-10s| %-10s| %-7s| %-5d| %-6d| %-18d|\n",
                    current.noTNKB, current.nama, current.jenis, current.cc, current.tahun, current.bulanHarusBayar);
            current = current.next;
        }
    }

    static void bayarPajak() {
        Scanner sc12 = new Scanner(System.in);
        System.out.println("----------------------------");
        System.out.println("Masukkan Data Pembayaran");
        System.out.println("----------------------------");
        System.out.print("Masukkan Nomer TNKB: ");
        String kodeKendaraan = sc12.nextLine();
        Kendaraan12 kendaraanDipilih = findKendaraan(kodeKendaraan);
        if (kendaraanDipilih == null) {
            System.out.println("Kendaraan tidak ditemukan.");
            return;
        }
        System.out.print("Bulan bayar: ");
        int bulanBayar = sc12.nextInt();
        long denda = 0;
        if (bulanBayar > kendaraanDipilih.bulanHarusBayar) {
            int selisihBulan = bulanBayar - kendaraanDipilih.bulanHarusBayar;
            if (selisihBulan <= 3) {
                denda = 50000 * selisihBulan;
            } else {
                denda = 50000 * 3 + 50000 * (selisihBulan - 3);
            }
        }

        long nominalBayar = 0;
        if (kendaraanDipilih.jenis.equalsIgnoreCase("motor")) {
            nominalBayar = hitungTarifPajakMotor(kendaraanDipilih.cc) + denda;
        } else if (kendaraanDipilih.jenis.equalsIgnoreCase("mobil")) {
            nominalBayar = hitungTarifPajakMobil(kendaraanDipilih.cc) + denda;
        }

        TransaksiPajak12 transaksiPajak = new TransaksiPajak12(0, nominalBayar, denda, bulanBayar); // otomatis
        insertTransaksi(transaksiPajak);
        kendaraanDipilih.setTransaksiPajak(transaksiPajak);

        System.out.println("Tabel Transaksi:");
        System.out.println("| Kode  | TNKB     | Nama   | Nominal      | Denda    |");
        System.out.printf("| %-6s| %-8s| %-7s| %-13d| %-9d|\n",
        transaksiPajak.kode, kendaraanDipilih.noTNKB, kendaraanDipilih.nama, nominalBayar, denda);        
    }

    static long hitungTarifPajakMotor(int ccMotor) {
        if (ccMotor < 100) {
            return 100000;
        } else if (ccMotor <= 250) {
            return 250000;
        } else {
            return 500000;
        }
    }

    static long hitungTarifPajakMobil(int ccMobil) {
        if (ccMobil < 1000) {
            return 750000;
        } else if (ccMobil <= 2500) {
            return 1000000;
        } else {
            return 1500000;
        }
    }

    static void tampilkanSeluruhTransaksi() {
        System.out.println("+++++++++++++++++++++++");
        System.out.println("Daftar Transaksi Pembayaran Pajak:");
        System.out.println("+++++++++++++++++++++++");
        System.out.println("| Kode  | TNKB     | Nama   | Nominal      | Denda    |");
        TransaksiPajak12 current = headTransaksi;
        long totalPendapatanHariIni = 0;
        while (current != null) {
            Kendaraan12 kendaraan = findKendaraanByTransaksi(current);
            if (kendaraan != null) {
                System.out.printf("| %-6s| %-8s| %-7s| %-13d| %-9d|\n",
                        current.kode, kendaraan.noTNKB, kendaraan.nama, current.nominalBayar, current.denda);
                        totalPendapatanHariIni += current.nominalBayar;
            }
            current = current.next;
        }
        System.out.println("Total Pendapatan Hari Ini: " + totalPendapatanHariIni);
    }
    static Kendaraan12 findKendaraanByTransaksi(TransaksiPajak12 transaksi) {
        Kendaraan12 current = headKendaraan;
        while (current != null) {
            if (current.transaksiPajak == transaksi) {
                return current;
            }
            current = current.next;
        }
        return null;
    }

    static Kendaraan12 findKendaraan(String kodeKendaraan) {
        if (headKendaraan == null) {
            System.out.println("Daftar kendaraan kosong.");
            return null;
        }

        Kendaraan12 current = headKendaraan;
        while (current != null) {
            if (current.noTNKB.equals(kodeKendaraan)) {
                return current;
            }
            current = current.next;
        }
        System.out.println("Kendaraan dengan Nomor TNBK " + kodeKendaraan + " tidak ditemukan.");
        return null;
    }
    
}
